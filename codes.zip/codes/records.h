#ifndef RECORDS_H
#define RECORDS_H

extern char playername[256];

void ManageScores(Font customFont, bool save, int score, Texture2D background, Music menuMusic) ;

#endif