#ifndef MAP_H
#define MAP_H

#define SIZE1 15
#define SIZE2 20

extern char a[SIZE1][SIZE2];

#endif