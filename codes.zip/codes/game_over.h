#ifndef GAME_OVER_H
#define GAME_OVER_H

bool GameOverScreen(int screenWidth, int screenHeight, void (*DrawGameState)(), int score);

#endif