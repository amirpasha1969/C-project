#ifndef BASE_H
#define BASE_H

void character_and_ghost_movement();

#endif